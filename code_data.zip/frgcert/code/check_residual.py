"""Largest interpolation-residual bound R_n over all steps, per configuration.

Writes results/residual_check.json: max_n,step R_n and the largest residual
contribution sum_n R_n L^(2n) on the certificate window.
"""
import json, os
import numpy as np
import frgcert as F

R = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'results')
out = {}
for dim, Ns, steps in ((0, range(2, 8), 2000), (3, range(2, 6), 1200)):
    for N in Ns:
        fn = os.path.join(R, 'cert', 'd%d_N%d.json' % (dim, N))
        L = json.load(open(fn))['ext']['L'] if os.path.exists(fn) else (14.0 if dim == 0 else 10.0)
        ts, cs, Ds = F.trajectory(dim, N, steps)
        mR = 0.0; mC = 0.0
        for j in range(steps):
            Rn = F.residual_bound(dim, N, cs[j], Ds[j], cs[j + 1], Ds[j + 1], ts[j], ts[j + 1])
            mR = max(mR, max(Rn)); mC = max(mC, sum(r * L**(2 * n) for n, r in enumerate(Rn)))
        out['d%d_N%d' % (dim, N)] = dict(max_R=mR, max_contribution_on_window=mC, L=L)
        print(dim, N, out['d%d_N%d' % (dim, N)], flush=True)
json.dump(out, open(os.path.join(R, 'residual_check.json'), 'w'), indent=1)
