"""Reference solutions of the untruncated local-potential flows and the true errors.

The references are method-of-lines integrations (eighth-order finite differences in the
field, classical RK4 in the flow variable) on [-Lg, Lg] with one-sided stencils at the
ends and no imposed boundary condition.  Their accuracy is established by halving the
step, halving the grid spacing and enlarging the domain.  They enter only the
true-error columns; the certificates do not use them.

Writes results/reference.json.
"""
import json, os, sys, time
import numpy as np
import frgcert as F

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'results')
X0 = 1.0


def fd_weights(z, x, m):
    n = len(x); c1 = 1.0; c4 = x[0] - z
    C = np.zeros((n, m + 1)); C[0, 0] = 1.0
    for i in range(1, n):
        mn = min(i, m); c2 = 1.0; c5 = c4; c4 = x[i] - z
        for j in range(i):
            c3 = x[i] - x[j]; c2 *= c3
            if j == i - 1:
                for s in range(mn, 0, -1):
                    C[i, s] = c1 * (s * C[i - 1, s - 1] - c5 * C[i - 1, s]) / c2
                C[i, 0] = -c1 * c5 * C[i - 1, 0] / c2
            for s in range(mn, 0, -1):
                C[j, s] = (c4 * C[j, s] - s * C[j, s - 1]) / c3
            C[j, 0] = c4 * C[j, 0] / c3
        c1 = c2
    return C[:, m]


def dmat(x, m, order=8):
    n = len(x); D = np.zeros((n, n)); h = order // 2
    for i in range(n):
        lo = max(0, min(i - h, n - order - 1)); idx = np.arange(lo, lo + order + 1)
        D[i, idx] = fd_weights(x[i], x[idx], m)
    return D


def ref_d0(nk=24000, dphi=0.025, Lg=6.0, record_every=120):
    nphi = int(round(2 * Lg / dphi)) + 1
    x = np.linspace(-Lg, Lg, nphi); D2 = dmat(x, 2)
    G = 0.5 * x**2 + x**4 / 24
    ks = np.linspace(F.LAMBDA, 0.0, nk + 1)
    f = lambda G, k: k / (D2 @ G + k * k)
    i0 = np.argmin(np.abs(x)); i1 = np.argmin(np.abs(x - X0))
    rec = [(ks[0], G[i0], G[i1] - G[i0])]; minv = np.inf
    inner = np.abs(x) <= Lg - 1.0
    for i in range(nk):
        k = ks[i]; h = ks[i + 1] - k
        a = f(G, k); b = f(G + .5 * h * a, k + .5 * h); c = f(G + .5 * h * b, k + .5 * h); d = f(G + h * c, k + h)
        G = G + h / 6 * (a + 2 * b + 2 * c + d)
        if (i + 1) % record_every == 0:
            rec.append((ks[i + 1], G[i0], G[i1] - G[i0]))
            minv = min(minv, (D2 @ G)[inner].min())
    return dict(G0=G[i0], G01=G[i1] - G[i0], min_G2=minv, rec=rec, x=x.tolist(), prof=G.tolist())


def ref_d3(ns=40000, dx=0.02, Lg=4.0, record_every=400):
    nx = int(round(2 * Lg / dx)) + 1
    x = np.linspace(-Lg, Lg, nx); D1 = dmat(x, 1); D2 = dmat(x, 2)
    u = 0.10 + 0.30 * x**2 + 0.020 * x**4; h = F.S_END / ns
    f = lambda u: 3 * u - 0.5 * x * (D1 @ u) - 1.0 / (1.0 + D2 @ u)
    i0 = np.argmin(np.abs(x)); i1 = np.argmin(np.abs(x - X0))
    rec = [(0.0, u[i0], u[i1] - u[i0])]; lemma = []
    inner = np.abs(x) <= Lg - 1.0
    for i in range(ns):
        a = f(u); b = f(u + .5 * h * a); c = f(u + .5 * h * b); d = f(u + h * c)
        u = u + h / 6 * (a + 2 * b + 2 * c + d)
        if (i + 1) % record_every == 0:
            s = (i + 1) * h
            rec.append((s, u[i0], u[i1] - u[i0]))
            lemma.append((s, float((D2 @ u)[inner].min()), F.W0_MIN * np.exp(2 * s)))
    return dict(u0=u[i0], u01=u[i1] - u[i0], lemma=lemma, rec=rec, x=x.tolist(), prof=u.tolist())


def trunc_values(dim, N, nsteps):
    ts, cs, Ds = F.trajectory(dim, N, nsteps)
    vals = [(float(t), float(c[0]), float(sum(c[n] * X0**(2 * n) for n in range(1, N + 1)))) for t, c in zip(ts, cs)]
    return vals


if __name__ == '__main__':
    t0 = time.time(); out = {}
    r = ref_d0(); out['d0'] = dict(G0=r['G0'], G01=r['G01'], min_G2_along_flow=r['min_G2'], rec=r['rec'], x=r['x'], prof=r['prof'])
    r_k = ref_d0(nk=12000); r_g = ref_d0(dphi=0.05); r_L = ref_d0(Lg=8.0)
    out['d0']['conv'] = dict(step=abs(r['G0'] - r_k['G0']), grid=abs(r['G0'] - r_g['G0']), domain=abs(r['G0'] - r_L['G0']),
                             step01=abs(r['G01'] - r_k['G01']), grid01=abs(r['G01'] - r_g['G01']), domain01=abs(r['G01'] - r_L['G01']))
    print('d0 reference', out['d0']['G0'], out['d0']['conv'], 'min G2', r['min_G2'], '%.0fs' % (time.time() - t0), flush=True)
    r = ref_d3(); out['d3'] = dict(u0=r['u0'], u01=r['u01'], lemma=r['lemma'], rec=r['rec'], x=r['x'], prof=r['prof'])
    r_s = ref_d3(ns=20000); r_g = ref_d3(dx=0.04); r_L = ref_d3(Lg=5.0)
    out['d3']['conv'] = dict(step=abs(r['u0'] - r_s['u0']), grid=abs(r['u0'] - r_g['u0']), domain=abs(r['u0'] - r_L['u0']),
                             step01=abs(r['u01'] - r_s['u01']), grid01=abs(r['u01'] - r_g['u01']), domain01=abs(r['u01'] - r_L['u01']))
    print('d3 reference', out['d3']['u0'], out['d3']['conv'], '%.0fs' % (time.time() - t0), flush=True)
    out['trunc'] = {}
    for dim, Ns, steps in ((0, range(2, 8), 2000), (3, range(2, 6), 1200)):
        for N in Ns:
            out['trunc']['d%d_N%d' % (dim, N)] = trunc_values(dim, N, steps)
    with open(os.path.join(OUT, 'reference.json'), 'w') as fh:
        json.dump(out, fh, indent=1)
    print('written', '%.0fs' % (time.time() - t0))
