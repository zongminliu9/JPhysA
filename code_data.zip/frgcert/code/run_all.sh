#!/bin/bash
# Runs every certificate, two at a time, then the reference solutions.
cd "$(dirname "$0")"
export TMPDIR="$(cd ..; pwd)/scratch"
for jb in "0 2" "0 3" "0 4" "0 5" "0 6" "0 7" "3 2" "3 3" "3 4" "3 5" "3 2 --mu1" "3 3 --mu1" "3 4 --mu1" "3 5 --mu1"; do
  set -- $jb
  tag="d$1_N$2${3:+_mu1}"
  python3 certify.py $jb > ../results/logs/cert_${tag}.log 2>&1 &
  while [ "$(jobs -rp | wc -l)" -ge 2 ]; do sleep 2; done
done
wait
python3 reference.py > ../results/logs/reference.log 2>&1
echo ALLDONE
