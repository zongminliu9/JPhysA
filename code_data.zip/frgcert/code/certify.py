"""Certificates for one vertex expansion.

usage: python3 certify.py DIM N [--steps n] [--quick]

Three certificates are computed for the same approximation:
  ext : Theorem 1 applied to the truncation continued quadratically beyond |phi| = L
        (Proposition 3); gives the bound on |e| at the origin,
  lat : the window construction with the corrected lateral estimate (Proposition 2),
        only when the truncation is not admissible on the whole line,
  der : the weighted energy bound for the field derivative of the error and the
        resulting bound on |e(x0) - e(0)| (Proposition 4), again for the continued
        truncation.
Parameters (L, beta, gamma) are selected by a floating-point search; the reported
values are upper bounds evaluated in ball arithmetic.  Output: results/cert/d{DIM}_N{N}.json
"""
import sys, json, math, time, os
import numpy as np
from flint import arb
import frgcert as F

DIM = int(sys.argv[1]); N = int(sys.argv[2])
QUICK = '--quick' in sys.argv
MU1 = '--mu1' in sys.argv          # d = 3 only: use the weaker convexity bound 1 + u'' >= 1
NSTEPS = int(sys.argv[sys.argv.index('--steps') + 1]) if '--steps' in sys.argv else (2000 if DIM == 0 else 1200)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'results', 'cert')
os.makedirs(OUT, exist_ok=True)
X0 = 1.0
WHOLE = 14.0 if DIM == 0 else 10.0      # explicitly resolved range for whole-line windows
SHIFT = (lambda t: t * t) if DIM == 0 else (lambda t: 1.0)
PI = arb.pi()
T0 = time.time()

ts, cs, Ds = F.trajectory(DIM, N, NSTEPS)


def log(*a):
    print(*a, flush=True)


def mu_exact_f(t):
    if DIM == 3 and MU1:
        return 1.0
    return 1.0 + t * t if DIM == 0 else 1.0 + F.W0_MIN * math.exp(2 * t)


def mu_exact_lo(tmin):
    if DIM == 3 and MU1:
        return 1.0
    return F.lo(arb(1) + arb(tmin)**2) if DIM == 0 else F.lo(1 + arb(F.W0_MIN) * (2 * arb(tmin)).exp())


def pref(t):
    """(1/2) d_k R_k in d = 0, the constant 1 in d = 3."""
    return t if DIM == 0 else 1.0


# ------------------------------------------------------------ floating point profiles
def fl_defect(j, f):
    t = ts[j]; Q = F.Q_float(cs[j], N, SHIFT(t)); s = F.series_inverse(Q, N)
    y = f * f; Qv = np.polyval(Q[::-1], y); T = np.polyval(s[::-1], y)
    dl = (t * (T - 1 / Qv)) if DIM == 0 else (1 / Qv - T)
    return dl, Qv


def fl_ext_coeffs(j, L):
    """g_i = d^i u~/dphi^i at L and their flow derivatives, for the quadratic continuation."""
    c, d = cs[j], Ds[j]
    def der(coef, i):
        return sum(coef[n] * math.perm(2 * n, i) * L**(2 * n - i) for n in range(len(coef)) if 2 * n >= i)
    g = [der(c, i) for i in range(3)]; gd = [der(d, i) for i in range(3)]
    if DIM == 0:
        b1, b2 = gd[1], 0.5 * gd[2]
    else:
        b1 = gd[1] - 2.5 * g[1] + 0.5 * L * g[2]
        b2 = 0.5 * gd[2] - g[2]
    return b1, b2


def fl_rows(L, nf=900, stride=4):
    ext = WHOLE if not np.isfinite(L) else L
    f = np.linspace(0, ext, nf); rows = []
    for j in range(0, NSTEPS, stride):
        h = abs(ts[min(j + stride, NSTEPS)] - ts[j])
        dl, Qv = fl_defect(j, f)
        if Qv.min() <= 0:
            return None
        b1, b2 = fl_ext_coeffs(j, L) if np.isfinite(L) else (0.0, 0.0)
        ddl = np.gradient(dl, f)
        rows.append(dict(t=ts[j], h=h, mut=Qv.min(), adl=np.abs(dl), supd=np.abs(dl).max(),
                         dL=abs(dl[-1]), b1=abs(b1), b2=abs(b2), ddl=ddl, f=f))
    return rows


def fl_ext_C(r, beta, L):
    C = (r['adl'] / np.cosh(beta * r['f'])).max()
    if np.isfinite(L):
        C = max(C, 2 * math.exp(-beta * L) * (r['dL'] + r['b1'] / (math.e * beta) + r['b2'] * (2 / (math.e * beta))**2))
    return C


def fl_barrier(rows, beta, L):
    A = B = 0.0
    for r in rows:
        C = fl_ext_C(r, beta, L); h = r['h']
        ab = pref(r['t']) / (r['mut'] * mu_exact_f(r['t']))
        if DIM == 0:
            q = ab * beta**2; B = B * math.exp(q * h) + C * (math.expm1(q * h) / q if q > 0 else h); A = B
        else:
            p = ab * beta**2 + 3
            A = A * math.exp(3 * h) + (B + C / p) * (math.exp(p * h) - math.exp(3 * h)) + C * math.expm1(3 * h) / p
            B = B * math.exp(p * h) + C * math.expm1(p * h) / p
    return A, B


def fl_lateral(rows, beta, gamma, L):
    A = B = 0.0; M = 0.0; Ia = 0.0; Iq = 0.0; mr = 0.0
    for r in rows:
        C = (r['adl'] / np.cosh(beta * r['f'])).max(); h = r['h']
        ab = pref(r['t']) / (r['mut'] * mu_exact_f(r['t'])); flux = max(pref(r['t']) / r['mut'], pref(r['t']) / mu_exact_f(r['t']))
        if DIM == 0:
            q = ab * beta**2; B = B * math.exp(q * h) + C * (math.expm1(q * h) / q if q > 0 else h); A = B
            M += h * (flux + r['supd']); Ia += ab * h
        else:
            p = ab * beta**2 + 3
            A = A * math.exp(3 * h) + (B + C / p) * (math.exp(p * h) - math.exp(3 * h)) + C * math.expm1(3 * h) / p
            B = B * math.exp(p * h) + C * math.expm1(p * h) / p
            M = M * math.exp(3 * h) + (flux + r['supd']) * math.expm1(3 * h) / 3
            mr = max(mr, M * math.exp(-Iq)); Iq += (3 + ab * gamma**2) * h
    lat = (M * math.exp(gamma**2 * Ia) if DIM == 0 else mr * math.exp(Iq)) / math.cosh(gamma * L)
    return A, lat


def fl_energy(rows, gE, L):
    Z = 0.0
    for r in rows:
        f = r['f']; w = 1 / np.cosh(gE * f)**2
        G2 = 2 * np.trapezoid(r['ddl']**2 * w, f)
        if np.isfinite(L):
            a_, b_ = r['b1'], 2 * r['b2']
            G2 += 2 * 4 * math.exp(-2 * gE * L) * (a_**2 / (2 * gE) + 2 * a_ * b_ / (2 * gE)**2 + 2 * b_**2 / (2 * gE)**3)
        ab = pref(r['t']) / (r['mut'] * mu_exact_f(r['t']))
        kap = ab * gE**2 + (0.0 if DIM == 0 else 2.75); h = r['h']
        Z = Z * math.exp(kap * h) + math.sqrt(G2) * math.expm1(kap * h) / kap
    pre = math.sqrt(X0 / 2 + math.sinh(2 * gE * X0) / (4 * gE))
    return pre * Z / math.sqrt(2)


def fl_rho():
    f = np.linspace(0, 12, 24001); y = f * f; r = np.inf; tr = None
    for j in range(NSTEPS + 1):
        Qv = np.polyval(F.Q_float(cs[j], N, SHIFT(ts[j]))[::-1], y)
        neg = np.where(Qv <= 0)[0]
        if len(neg) and f[neg[0]] < r:
            r = f[neg[0]]; tr = ts[j]
    return r, tr


rho_f, t_rho = fl_rho()
log("d=%d N=%d  rho(float)=%s at t=%s" % (DIM, N, rho_f, t_rho))
Lcand = ([0.98 * rho_f * x for x in np.linspace(0.55, 1.0, 10)] if np.isfinite(rho_f)
         else [WHOLE * x for x in (0.2, 0.3, 0.4, 0.55, 0.7, 0.85, 1.0)])
betas = np.arange(0.5, 7.01, 0.25); gammas = np.arange(1.0, 12.01, 0.5); gEs = np.arange(0.25, 4.01, 0.25)
rows_cache = {}
for L in Lcand:
    rr = fl_rows(L)
    if rr is not None:
        rows_cache[L] = rr
bar_grid = [(fl_barrier(rr, b, L), L, b) for L, rr in rows_cache.items() for b in betas]
ext_grid = [(AB[0], L, b) for AB, L, b in bar_grid]
best_ext = min(ext_grid, key=lambda z: z[0])
fd_grid = [(2 * AB[0] + AB[1] * (math.cosh(b * X0) - 1), L, b) for AB, L, b in bar_grid]
best_fd = min(fd_grid, key=lambda z: z[0])
beta_curve = [[float(b), v] for v, L, b in ext_grid if L == best_ext[1]]
L_curve = [[float(L), min(v for v, LL, b in ext_grid if LL == L)] for L in rows_cache]
best_der = min(((fl_energy(rr, g, L), L, g) for L, rr in rows_cache.items() for g in gEs), key=lambda z: z[0])
best_lat = None
if np.isfinite(rho_f):
    for L, rr in rows_cache.items():
        for b in betas[::2]:
            for g in gammas:
                Aint, lat = fl_lateral(rr, b, g, L)
                if best_lat is None or Aint + lat < best_lat[0]:
                    best_lat = (Aint + lat, Aint, lat, L, b, g)
log("float: fd %.4e (L=%s beta=%.2f)" % best_fd)
log("float: ext %.4e (L=%s beta=%.2f) | der %.4e (L=%s gE=%.2f) | lat %s" %
    (best_ext[0], best_ext[1], best_ext[2], best_der[0], best_der[1], best_der[2],
     None if best_lat is None else "%.4e (int %.3e lat %.3e L=%.3f beta=%.2f gamma=%.1f)" % best_lat))


# ------------------------------------------------------------ ball arithmetic
def kind_val(sc, a, b, kind, beta):
    yb = F.hull(a * a, b * b)
    if kind == 'Q':
        return F.lo(F.horner(sc['Q'], yb))
    d, _ = F.defect_on(sc, DIM, N, yb)
    if kind == 'sup':
        return F.up(abs(d))
    return F.up(abs(d) / arb(a * beta).cosh())


def sweep(sc, ext, kind, beta, target=None, nbox=48):
    br = F.grid_breaks(ext, nbox)
    fun = lambda u, v: kind_val(sc, u, v, kind, beta)
    if kind == 'Q':
        return min(F.box_min(fun, a, b) for a, b in zip(br[:-1], br[1:]))
    return max(F.box_max(fun, a, b) for a, b in zip(br[:-1], br[1:]))


def ext_coeffs_arb(sc, L):
    """Enclosures of |delta(L)|, |b1|, |b2| over the step for the continuation at L."""
    H = sc['H']; Hd = sc['Hd']; La = arb(L)
    def der(coef, i):
        v = arb(0)
        for n in range(len(coef)):
            if 2 * n >= i:
                v = v + coef[n] * math.perm(2 * n, i) * La**(2 * n - i)
        return v
    g = [der(H, i) for i in range(3)]; gd = [der(Hd, i) for i in range(3)]
    if DIM == 0:
        b1, b2 = gd[1], gd[2] / 2
    else:
        b1 = gd[1] - g[1] * 5 / 2 + La * g[2] / 2
        b2 = gd[2] / 2 - g[2]
    dL, _ = F.defect_on(sc, DIM, N, La * La)
    return F.up(abs(dL)), F.up(abs(b1)), F.up(abs(b2))


def tail_whole(sc, beta):
    """Whole-line tail beyond WHOLE for a globally admissible truncation."""
    Y0 = WHOLE**2; Q = sc['Q']; n = len(Q); sh = [arb(0)] * n
    for i, qi in enumerate(Q):
        for m in range(i + 1):
            sh[m] = sh[m] + qi * math.comb(i, m) * arb(Y0)**(i - m)
    if any(F.lo(c) < 0 for c in sh[1:]):
        raise RuntimeError('whole-line tail: Q not monotone beyond Y0')
    Qmin = F.lo(sh[0]); g = {}
    for m, p in sc['P'].items():
        g[m] = g.get(m, 0.0) + F.up(abs(p)) * (F.up(sc['t']) if DIM == 0 else 1.0) / Qmin
    for m, r in enumerate(sc['R']):
        g[m] = g.get(m, 0.0) + r
    deg = 2 * max(g)
    assert deg <= 0.99 * beta * WHOLE * math.tanh(beta * WHOLE)
    return Qmin, sum(c * Y0**m for m, c in g.items()) / math.cosh(beta * WHOLE)


def run():
    Le, be = best_ext[1], best_ext[2]
    Ld, gE = best_der[1], best_der[2]
    do_lat = best_lat is not None
    if do_lat:
        Ll, bl, gl = best_lat[3], best_lat[4], best_lat[5]
    st = dict(A=arb(0), B=arb(0), Al=arb(0), Bl=arb(0), M=arb(0), Ia=arb(0), Iq=arb(0), mr=arb(0), Z=arb(0), Af=arb(0), Bf=arb(0))
    Lf, bf = best_fd[1], best_fd[2]
    hist = []; steps = []
    for j in range(NSTEPS):
        sc = F.step_coeffs(DIM, N, cs[j], Ds[j], cs[j + 1], Ds[j + 1], ts[j], ts[j + 1])
        tmin, tmax = min(ts[j], ts[j + 1]), max(ts[j], ts[j + 1])
        h = arb(abs(ts[j + 1] - ts[j])); mu = arb(mu_exact_lo(tmin)); num = arb(tmax) if DIM == 0 else arb(1)
        cache = {}

        def mut_on(L):
            if L in cache:
                return cache[L]
            ext = WHOLE if not np.isfinite(L) else L
            _, Qv = fl_defect(j, np.linspace(0, ext, 300))
            m = sweep(sc, ext, 'Q', None, 0.98 * Qv.min())
            if not np.isfinite(L):
                m = min(m, tail_whole(sc, 1.0)[0])
            if m <= 0:
                raise RuntimeError('admissibility not certified (step %d, L=%s)' % (j, L))
            cache[L] = m
            return m

        def C_ext(L, beta):
            ext = WHOLE if not np.isfinite(L) else L
            dl, _ = fl_defect(j, np.linspace(0, ext, 400))
            C = sweep(sc, ext, 'C', beta, 1.03 * (np.abs(dl) / np.cosh(beta * np.linspace(0, ext, 400))).max())
            if np.isfinite(L):
                dL, b1, b2 = ext_coeffs_arb(sc, L)
                eb = arb(math.e) * beta
                C = max(C, F.up(2 * (-arb(beta) * arb(L)).exp() * (dL + b1 / eb + b2 * (2 / eb)**2)))
            else:
                C = max(C, tail_whole(sc, beta)[1])
            return arb(C)

        # --- ext: Theorem 1 for the continued truncation
        ab = num / (arb(mut_on(Le)) * mu); C = C_ext(Le, be)
        steps.append([float(ts[j]), float(ts[j + 1]), F.up(C), F.up(ab), mut_on(Le)])
        if DIM == 0:
            q = ab * be**2; e = (q * h).exp()
            st['B'] = st['B'] * e + C * (e - 1) / q; st['A'] = st['B']
        else:
            p = ab * be**2 + 3; e3 = (3 * h).exp(); ep = (p * h).exp()
            st['A'] = st['A'] * e3 + (st['B'] + C / p) * (ep - e3) + C * (e3 - 1) / p
            st['B'] = st['B'] * ep + C * (ep - 1) / p
        # --- fd: Theorem 1 with its own beta for the field-dependent part at x0
        abf = num / (arb(mut_on(Lf)) * mu); Cf = C_ext(Lf, bf) if (Lf, bf) != (Le, be) else C
        if DIM == 0:
            q = abf * bf**2; e = (q * h).exp()
            st['Bf'] = st['Bf'] * e + Cf * (e - 1) / q; st['Af'] = st['Bf']
        else:
            p = abf * bf**2 + 3; e3 = (3 * h).exp(); ep = (p * h).exp()
            st['Af'] = st['Af'] * e3 + (st['Bf'] + Cf / p) * (ep - e3) + Cf * (e3 - 1) / p
            st['Bf'] = st['Bf'] * ep + Cf * (ep - 1) / p
        # --- lat: corrected window estimate
        latv = None
        if do_lat:
            abl = num / (arb(mut_on(Ll)) * mu)
            dl, _ = fl_defect(j, np.linspace(0, Ll, 400))
            Cl = arb(sweep(sc, Ll, 'C', bl, 1.03 * (np.abs(dl) / np.cosh(bl * np.linspace(0, Ll, 400))).max()))
            supd = sweep(sc, Ll, 'sup', None, 1.03 * np.abs(dl).max())
            flux = max(F.up(num / arb(mut_on(Ll))), F.up(num / mu))
            if DIM == 0:
                q = abl * bl**2; e = (q * h).exp()
                st['Bl'] = st['Bl'] * e + Cl * (e - 1) / q; st['Al'] = st['Bl']
                st['M'] = st['M'] + h * (flux + supd); st['Ia'] = st['Ia'] + abl * h
                latv = st['M'] * (arb(gl)**2 * st['Ia']).exp() / (arb(gl) * arb(Ll)).cosh()
            else:
                p = abl * bl**2 + 3; e3 = (3 * h).exp(); ep = (p * h).exp()
                st['Al'] = st['Al'] * e3 + (st['Bl'] + Cl / p) * (ep - e3) + Cl * (e3 - 1) / p
                st['Bl'] = st['Bl'] * ep + Cl * (ep - 1) / p
                st['M'] = st['M'] * e3 + (flux + supd) * (e3 - 1) / 3
                st['mr'] = arb(max(F.up(st['mr']), F.up(st['M'] * (-st['Iq']).exp())))
                st['Iq'] = st['Iq'] + (3 + abl * gl**2) * h
                latv = st['mr'] * st['Iq'].exp() / (arb(gl) * arb(Ll)).cosh()
        # --- der: energy bound for the field derivative of the error
        ext = WHOLE if not np.isfinite(Ld) else Ld
        abd = num / (arb(mut_on(Ld)) * mu)
        kap = abd * gE**2 + (0 if DIM == 0 else arb(11) / 4)
        br = F.grid_breaks(ext, 240); G2 = arb(0); gEa = arb(gE)
        for a, b in zip(br[:-1], br[1:]):
            dd = F.ddefect_dy_on(sc, DIM, N, F.hull(a * a, b * b))
            sp = F.up(2 * arb(b) * abs(dd))
            G2 = G2 + arb(sp)**2 * ((gEa * b).tanh() - (gEa * a).tanh()) / gEa
        if np.isfinite(Ld):
            dL, b1, b2 = ext_coeffs_arb(sc, Ld)
            a_, b_ = arb(b1), arb(2 * b2)
            G2 = G2 + 4 * (-2 * gEa * arb(Ld)).exp() * (a_**2 / (2 * gEa) + 2 * a_ * b_ / (2 * gEa)**2 + 2 * b_**2 / (2 * gEa)**3)
        else:
            raise RuntimeError('energy bound requires a finite continuation point')
        G = (2 * G2).sqrt(); ek = (kap * h).exp()
        st['Z'] = st['Z'] * ek + G * (ek - 1) / kap
        hist.append([float(ts[j + 1]), F.up(st['A']), None if latv is None else F.up(st['Al']), None if latv is None else F.up(latv)])
        if j % (NSTEPS // 10) == 0:
            log("  step %4d/%d t=%.3f ext=%.3e lat=%s Z=%.3e  %.0fs" %
                (j, NSTEPS, ts[j + 1], hist[-1][1], None if latv is None else "%.3e+%.3e" % (hist[-1][2], hist[-1][3]),
                 F.up(st['Z']), time.time() - T0))
        if QUICK and j > NSTEPS // 20:
            break
    pre = ((arb(X0) / 2 + (2 * gEa * X0).sinh() / (4 * gEa)) / 2).sqrt()
    fdb = 2 * st['Af'] + st['Bf'] * ((arb(bf) * X0).cosh() - 1)
    return dict(ext=dict(L=None if not np.isfinite(Le) else float(Le), beta=float(be), bound=F.up(st['A']), B=F.up(st['B'])),
                fd=dict(L=float(Lf), beta=float(bf), x0=X0, bound=F.up(fdb)),
                lat=None if not do_lat else dict(L=float(Ll), beta=float(bl), gamma=float(gl),
                                                 interior=hist[-1][2], lateral=hist[-1][3], bound=hist[-1][2] + hist[-1][3]),
                der=dict(L=float(Ld), gammaE=float(gE), x0=X0, bound=F.up(pre * st['Z']), sqrtE=F.up(st['Z'])),
                history=hist, steps=steps)


def rho_bracket():
    if not np.isfinite(rho_f):
        return dict(rho='inf')
    jr = int(np.argmin([abs(t - t_rho) for t in ts]))
    Qn = F.Q_arb([arb(float(c)) for c in cs[jr]], N, arb(SHIFT(ts[jr])))
    hi = next((round(f, 4) for f in np.arange(0.99 * rho_f, 1.02 * rho_f, 0.0002) if F.up(F.horner(Qn, arb(f * f))) < 0), None)
    lo_ = math.floor(0.998 * rho_f * 1000) / 1000
    for j in range(NSTEPS):
        sc = F.step_coeffs(DIM, N, cs[j], Ds[j], cs[j + 1], Ds[j + 1], ts[j], ts[j + 1])
        if sweep(sc, lo_, 'Q', None, 1e-12, nbox=96) <= 0:
            lo_ = None; break
        if QUICK and j > 5:
            break
    return dict(rho_lo=lo_, rho_hi=hi, t_at_boundary=float(t_rho))


res = run()
rb = rho_bracket()
out = dict(dim=DIM, N=N, nsteps=NSTEPS, quick=QUICK, mu1=MU1, float=dict(ext=best_ext[0], der=best_der[0], lat=None if best_lat is None else best_lat[0],
                                                               beta_curve=beta_curve, L_curve=L_curve),
           rho_float=('inf' if not np.isfinite(rho_f) else float(rho_f)), **rb, **res,
           final_coeffs=[float(c) for c in cs[-1]], seconds=time.time() - T0)
fn = os.path.join(OUT, ('quick_' if QUICK else '') + 'd%d_N%d%s.json' % (DIM, N, '_mu1' if MU1 else ''))
with open(fn, 'w') as fh:
    json.dump(out, fh, indent=1)
log("DONE d=%d N=%d ext=%.4e fd=%.4e der=%.4e lat=%s rho=%s %.0fs" %
    (DIM, N, out['ext']['bound'], out['fd']['bound'], out['der']['bound'], None if out['lat'] is None else "%.4e" % out['lat']['bound'], rb, out['seconds']))
