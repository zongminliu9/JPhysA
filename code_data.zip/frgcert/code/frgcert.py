"""Certified a posteriori error bounds for vertex expansions of local-potential flows.

Two flows are treated.

d = 0:  d_k Gamma = k / (Gamma'' + k^2),            k from LAMBDA = 4 down to 0,
        Gamma_LAMBDA(phi) = phi^2/2 + phi^4/24.
d = 3:  d_s u = 3u - (x/2) u' - 1/(1 + u''),        s = -t from 0 to S = 1.2,
        u(0, x) = 0.1 + 0.3 x^2 + 0.02 x^4.

A vertex expansion of order N is an even polynomial of degree 2N in the field whose
coefficients obey the Taylor-projected flow.  The approximation that is certified is
the piecewise cubic Hermite interpolant (in k or s) of a fourth-order Runge-Kutta
solution of the coefficient equations; its defect is enclosed in Arb ball arithmetic
(python-flint), including the interpolation residual.  Floating-point routines are
used only to choose the free parameters (beta, gamma, L) and for the reference
solutions that supply the true errors.
"""
import numpy as np
from flint import arb, arb_series, ctx

ctx.prec = 106

LAMBDA = 4.0
D0_INIT = [0.0, 0.5, 1.0 / 24.0]
S_END = 1.2
D3_INIT = [0.10, 0.30, 0.020]
W0_MIN = 0.6      # min_x u''(0, x) for the d = 3 initial condition


# ----------------------------------------------------------------- floating point
def series_inverse(Q, N):
    s = np.zeros(N + 1); s[0] = 1.0 / Q[0]
    for n in range(1, N + 1):
        acc = 0.0
        for j in range(1, min(n, len(Q) - 1) + 1):
            acc += Q[j] * s[n - j]
        s[n] = -acc / Q[0]
    return s


def Q_float(c, N, shift):
    """Gamma~'' + R (d=0, shift=k^2) or 1 + u~'' (d=3, shift=1) as polynomial in y = field^2."""
    Q = np.array([c[n] * 2 * n * (2 * n - 1) for n in range(1, N + 1)], dtype=float)
    Q[0] += shift
    return Q


def rhs_float(dim, c, t, N):
    if dim == 0:
        return t * series_inverse(Q_float(c, N, t * t), N)
    s = series_inverse(Q_float(c, N, 1.0), N)
    return np.array([(3.0 - n) * c[n] - s[n] for n in range(N + 1)])


def trajectory(dim, N, nsteps):
    """RK4 nodes t_j and coefficient vectors c_j together with the derivative data D_j."""
    init = D0_INIT if dim == 0 else D3_INIT
    t0, t1 = (LAMBDA, 0.0) if dim == 0 else (0.0, S_END)
    ts = np.linspace(t0, t1, nsteps + 1)
    c = np.zeros(N + 1); c[:len(init)] = init[:N + 1]
    cs = [c.copy()]
    for i in range(nsteps):
        t = ts[i]; h = ts[i + 1] - t
        a = rhs_float(dim, c, t, N); b = rhs_float(dim, c + .5 * h * a, t + .5 * h, N)
        cc = rhs_float(dim, c + .5 * h * b, t + .5 * h, N); d = rhs_float(dim, c + h * cc, t + h, N)
        c = c + h / 6 * (a + 2 * b + 2 * cc + d)
        cs.append(c.copy())
    cs = np.array(cs)
    Ds = np.array([rhs_float(dim, cs[j], ts[j], N) for j in range(len(ts))])
    return ts, cs, Ds


# ----------------------------------------------------------------- ball arithmetic
def A(x):
    return x if isinstance(x, arb) else arb(float(x))


def hull(lo, hi):
    return A(lo).union(A(hi))


def up(x):
    return float(A(x).upper())


def lo(x):
    return float(A(x).lower())


def horner(coefs, y):
    v = arb(0)
    for c in reversed(coefs):
        v = v * y + c
    return v


def _hermite_monomial(cj, Dj, cn, Dn, ta, tb):
    """Coefficients of the cubic Hermite interpolant as a polynomial in tau = t - ta."""
    h = A(tb) - A(ta)
    out = []
    for n in range(len(cj)):
        c0, d0, c1, d1 = A(cj[n]), A(Dj[n]), A(cn[n]), A(Dn[n])
        a2 = (3 * (c1 - c0) / h - 2 * d0 - d1) / h
        a3 = (2 * (c0 - c1) / h + d0 + d1) / (h * h)
        out.append((c0, d0, a2, a3))
    return out


def hermite(cj, Dj, cn, Dn, ta, tb, t):
    """Cubic Hermite interpolant on [ta, tb] evaluated at t (arb, ball or arb_series)."""
    tau = t - A(ta)
    return [c0 + tau * (d0 + tau * (a2 + tau * a3)) for c0, d0, a2, a3 in _hermite_monomial(cj, Dj, cn, Dn, ta, tb)]


def Q_arb(c, N, shift):
    return [c[1] * 2 + shift] + [c[n] * (2 * n * (2 * n - 1)) for n in range(2, N + 1)]


def s_arb(Q, N):
    s = [1 / Q[0]]
    for n in range(1, N + 1):
        acc = 0
        for j in range(1, min(n, len(Q) - 1) + 1):
            acc = acc + Q[j] * s[n - j]
        s.append(-acc / Q[0])
    return s


def P_tail(Q, s, N):
    """Coefficients p_n (n = N+1 .. 2N-1) of Q*T_N - 1; the lower ones vanish identically."""
    out = {}
    for n in range(N + 1, 2 * N):
        acc = 0
        for j in range(n - N, min(n, len(Q) - 1) + 1):
            acc = acc + Q[j] * s[n - j]
        out[n] = acc
    return out


def rhs_arb(dim, c, t, N):
    if dim == 0:
        s = s_arb(Q_arb(c, N, t * t), N)
        return [t * s[n] for n in range(N + 1)]
    s = s_arb(Q_arb(c, N, 1), N)
    return [(3 - n) * c[n] - s[n] for n in range(N + 1)]


def hermite_deriv(cj, Dj, cn, Dn, ta, tb, t):
    """Derivative in t of the cubic Hermite interpolant."""
    tau = t - A(ta)
    return [d0 + tau * (2 * a2 + tau * 3 * a3) for c0, d0, a2, a3 in _hermite_monomial(cj, Dj, cn, Dn, ta, tb)]


def _f_series(dim, N, Hs, tser):
    if dim == 0:
        Q = [Hs[1] * 2 + tser * tser] + [Hs[n] * (2 * n * (2 * n - 1)) for n in range(2, N + 1)]
    else:
        Q = [Hs[1] * 2 + 1] + [Hs[n] * (2 * n * (2 * n - 1)) for n in range(2, N + 1)]
    s = [1 / Q[0]]
    for n in range(1, N + 1):
        acc = 0 * Q[0]
        for j in range(1, min(n, len(Q) - 1) + 1):
            acc = acc + Q[j] * s[n - j]
        s.append(-acc / Q[0])
    return [tser * s[n] if dim == 0 else Hs[n] * (3 - n) - s[n] for n in range(N + 1)]


def residual_bound(dim, N, cj, Dj, cn, Dn, ta, tb):
    """Upper bounds R_n >= sup over the step of |H_n'(t) - f_n(H(t), t)|.

    The residual r is bounded by max(|r(ta)|, |r(tb)|) + h^2/8 sup|r''|; r'' is
    enclosed through the Taylor coefficients of r expanded at the ball covering the
    step, so the enclosure holds at every point of the step."""
    h = abs(tb - ta)
    ends = []
    for t in (ta, tb):
        tt = A(t)
        H0 = hermite(cj, Dj, cn, Dn, ta, tb, tt)
        dH = hermite_deriv(cj, Dj, cn, Dn, ta, tb, tt)
        f = rhs_arb(dim, H0, tt, N)
        ends.append([abs(dH[n] - f[n]) for n in range(N + 1)])
    tball = hull(min(ta, tb), max(ta, tb))
    tser = arb_series([tball, 1], prec=4)
    Hs = hermite(cj, Dj, cn, Dn, ta, tb, tser)
    fs = _f_series(dim, N, Hs, tser)
    R = []
    for n in range(N + 1):
        co = (Hs[n].derivative() - fs[n]).coeffs()
        r2 = 2 * abs(co[2]) if len(co) > 2 else arb(0)
        R.append(max(up(ends[0][n]), up(ends[1][n])) + up(r2) * h * h / 8)
    return R


def _QsP_series(dim, N, Hs, tser):
    if dim == 0:
        Q = [Hs[1] * 2 + tser * tser] + [Hs[n] * (2 * n * (2 * n - 1)) for n in range(2, N + 1)]
    else:
        Q = [Hs[1] * 2 + 1] + [Hs[n] * (2 * n * (2 * n - 1)) for n in range(2, N + 1)]
    sv = [1 / Q[0]]
    for n in range(1, N + 1):
        acc = 0 * Q[0]
        for jj in range(1, min(n, len(Q) - 1) + 1):
            acc = acc + Q[jj] * sv[n - jj]
        sv.append(-acc / Q[0])
    P = {}
    for n in range(N + 1, 2 * N):
        acc = 0 * Q[0]
        for jj in range(n - N, min(n, len(Q) - 1) + 1):
            acc = acc + Q[jj] * sv[n - jj]
        P[n] = acc
    return Q, P


def step_coeffs(dim, N, cj, Dj, cn, Dn, ta, tb):
    """Enclosures of Q, the tail P and the residual bounds over one step.

    Q and P are enclosed in centred form: their exact values at the midpoint of the
    step plus a ball enclosure of their t-derivative over the step times h/2."""
    tball = hull(min(ta, tb), max(ta, tb))
    tmid = A(0.5 * (ta + tb)); half = hull(-0.5 * abs(tb - ta), 0.5 * abs(tb - ta))
    Hm = hermite(cj, Dj, cn, Dn, ta, tb, tmid)
    Qm = Q_arb(Hm, N, tmid * tmid if dim == 0 else arb(1))
    Pm = P_tail(Qm, s_arb(Qm, N), N)
    tser = arb_series([tball, 1], prec=2)
    Qs, Ps = _QsP_series(dim, N, hermite(cj, Dj, cn, Dn, ta, tb, tser), tser)
    def slope(x):
        c = x.coeffs()
        return c[1] if len(c) > 1 else arb(0)
    Q = [Qm[n] + slope(Qs[n]) * half for n in range(len(Qm))]
    P = {n: Pm[n] + slope(Ps[n]) * half for n in Pm}
    R = residual_bound(dim, N, cj, Dj, cn, Dn, ta, tb)
    H = hermite(cj, Dj, cn, Dn, ta, tb, tball)
    Hd = hermite_deriv(cj, Dj, cn, Dn, ta, tb, tball)
    return dict(t=tball, Q=Q, P=P, R=R, H=H, Hd=Hd)


def defect_on(sc, dim, N, yb):
    """Ball enclosure of delta on a y-box (y = field^2)."""
    Qv = horner(sc['Q'], yb)
    Pv = arb(0)
    for n, p in sc['P'].items():
        Pv = Pv + p * yb**n
    Rv = arb(0)
    ymax = A(yb.upper())
    for n, r in enumerate(sc['R']):
        Rv = Rv + A(r) * ymax**n
    tail = (sc['t'] * Pv / Qv) if dim == 0 else (-Pv / Qv)
    return tail + hull(-up(Rv), up(Rv)), Qv


def ddefect_dy_on(sc, dim, N, yb):
    """Enclosure of d(delta)/dy on a y-box."""
    Qv = horner(sc['Q'], yb)
    dQ = horner([sc['Q'][j] * j for j in range(1, len(sc['Q']))], yb) if len(sc['Q']) > 1 else arb(0)
    Pv = arb(0); dP = arb(0)
    for n, p in sc['P'].items():
        Pv = Pv + p * yb**n; dP = dP + p * n * yb**(n - 1)
    ymax = A(yb.upper()); Rv = arb(0)
    for n, r in enumerate(sc['R']):
        if n >= 1:
            Rv = Rv + A(r) * n * ymax**(n - 1)
    q = (dP * Qv - Pv * dQ) / (Qv * Qv)
    tail = sc['t'] * q if dim == 0 else -q
    return tail + hull(-up(Rv), up(Rv))


def box_max(fun, a, b, target=None, tol=0.02, maxdepth=16, point=None):
    """Upper bound of sup_[a,b] of an interval function by branch and bound.

    fun(u, v) is an upper bound on [u, v]; point(x) (default fun(x, x)) a value at x.
    Boxes are refined while their bound exceeds (1 + tol) times the largest point value
    found so far; the result is the maximum bound over the final boxes."""
    point = point or (lambda x: fun(x, x))
    stack = [(a, b, 0)]; best = max(point(a), point(b), point(0.5 * (a + b))); out = 0.0
    while stack:
        u, v, dep = stack.pop()
        val = fun(u, v)
        if val <= (1 + tol) * best or dep >= maxdepth:
            out = max(out, val)
            continue
        m = 0.5 * (u + v)
        best = max(best, point(m))
        stack.append((u, m, dep + 1)); stack.append((m, v, dep + 1))
    return out


def box_min(fun, a, b, target=None, tol=0.02, maxdepth=16, point=None):
    """Lower bound of inf_[a,b] of an interval function by branch and bound."""
    point = point or (lambda x: fun(x, x))
    stack = [(a, b, 0)]; best = min(point(a), point(b), point(0.5 * (a + b))); out = float('inf')
    while stack:
        u, v, dep = stack.pop()
        val = fun(u, v)
        if val >= best - tol * abs(best) or dep >= maxdepth:
            out = min(out, val)
            continue
        m = 0.5 * (u + v)
        best = min(best, point(m))
        stack.append((u, m, dep + 1)); stack.append((m, v, dep + 1))
    return out


def grid_breaks(L, n):
    return np.linspace(0.0, L, n + 1)
