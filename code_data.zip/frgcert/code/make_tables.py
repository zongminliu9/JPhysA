"""Generate src/numbers.tex and the table files from the certificate and reference JSON.

Certificates are rounded up, true errors to nearest; ratios use unrounded values.
"""
import json, math, os, glob
import numpy as np

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
R = os.path.join(ROOT, 'results'); SRC = os.path.join(ROOT, 'src')
ref = json.load(open(os.path.join(R, 'reference.json')))
rs = json.load(open(os.path.join(R, 'rho_scan.json')))
cert = {}
for fn in glob.glob(os.path.join(R, 'cert', 'd*_N*.json')):
    key = os.path.basename(fn)[:-5]
    if key.startswith('quick'):
        continue
    cert[key] = json.load(open(fn))


def sci_up(x, d=2):
    """x rounded up to d significant digits, as LaTeX."""
    if x == 0:
        return '$0$'
    e = math.floor(math.log10(abs(x)))
    m = math.ceil(x / 10**(e - d + 1) - 1e-9) * 10**(-d + 1)
    if m >= 10:
        m /= 10; e += 1
    return r'$%.*f\times10^{%d}$' % (d - 1, m, e)


def sci(x, d=2):
    e = math.floor(math.log10(abs(x))); m = x / 10**e
    if round(m, d - 1) >= 10:
        m /= 10; e += 1
    return r'$%.*f\times10^{%d}$' % (d - 1, m, e)


def ratio(x):
    if x < 10:
        return '%.2f' % x
    if x < 100:
        return '%.1f' % x
    return '%d' % round(x)


def up_sig(x, d=2):
    e = math.floor(math.log10(abs(x)))
    return math.ceil(x / 10**(e - d + 1) - 1e-9) * 10**(e - d + 1)


def true_err(dim, N):
    tr = ref['trunc']['d%d_N%d' % (dim, N)][-1]
    if dim == 0:
        return abs(tr[1] - ref['d0']['G0']), abs(tr[2] - ref['d0']['G01'])
    return abs(tr[1] - ref['d3']['u0']), abs(tr[2] - ref['d3']['u01'])


def decomposition(c):
    """Split the certificate into injected defect, constant-mode amplification, diffusion."""
    st = c['steps']; S = max(max(a, b) for a, b, *_ in st) if c['dim'] == 3 else None
    inj = sum(abs(b - a) * C for a, b, C, ab, mu in st)
    if c['dim'] == 0:
        return inj, 0.0, c['ext']['bound'] - inj
    amp = sum(abs(b - a) * C * math.exp(3 * (S - b)) for a, b, C, ab, mu in st)
    return inj, amp - inj, c['ext']['bound'] - amp


macros = {}
lines = []
# ---------------------------------------------------------------- table 1 (d = 0)
rows = []
ratios0 = {}
for N in range(2, 8):
    c = cert.get('d0_N%d' % N)
    if c is None:
        continue
    e0, _ = true_err(0, N)
    b = c['ext']['bound']; ratios0[N] = b / e0
    inj, _, dif = decomposition(c)
    lat = sci_up(c['lat']['bound']) if c['lat'] else '---'
    Lx = c['ext']['L']
    rows.append('%d & %s & %s & %s & %s & %s & %s & %.2f & %.2f \\\\' %
                (N, sci(e0), sci_up(b), ratio(b / e0), sci_up(inj), sci_up(dif), lat, c['ext']['beta'], Lx))
tab = r"""\begin{table}[h]
\centering
\caption{\rev{Zero dimensions, $\lambda=1$, $\Lambda=4$, $k_0=0$: true error at $k=0$, $\varphi=0$ against the
certificate of Theorem~\ref{thm:main} for the continuation at $|\varphi|=L$
(Proposition~\ref{prop:cont}), its split into the defect injected along the flow,
$\int_0^SC\,ds$, and the diffusive growth of that defect, and, for $N\ge4$, the window
certificate of Proposition~\ref{prop:lateral}. The barrier width $\beta$ and the window
$L$ minimise the certificate: $\beta$ on a grid of spacing $0.25$, $L$ on ten values
below $\rho_N$ (for $N=2,3$, where $\rho_N=\infty$, on values up to 14). Moving
$\beta$ by $\pm0.5$ from the optimum changes the certificate by \BetaSensitivity\ in
either dimension. Certificates are upper bounds in ball arithmetic, rounded up.}}
\label{tab:d0}
\small\setlength{\tabcolsep}{4pt}
\begin{tabular}{ccccccccc}
\hline\hline
$N$ & true error & certificate & ratio & defect & diffusion & Prop.~\ref{prop:lateral} & $\beta$ & $L$ \\
\hline
""" + '\n'.join(rows) + r"""
\hline\hline
\end{tabular}
\end{table}
"""
open(os.path.join(SRC, 'tab_d0.tex'), 'w').write(tab)
macros['RatioDzeroNtwo'] = '%.1f' % (math.ceil(ratios0[2] * 10) / 10)
macros['RatioDzeroNthree'] = '%.1f' % (math.ceil(ratios0[3] * 10) / 10)
macros['RatioDzeroRange'] = '%d' % math.ceil(max(ratios0[n] for n in range(2, 6) if n in ratios0))
lats = [cert['d0_N%d' % N]['lat']['bound'] for N in (5, 6, 7) if 'd0_N%d' % N in cert]
if lats:
    macros['LatDzeroRange'] = 'between %s and %s' % (sci_up(min(lats)), sci_up(max(lats)))
for N, name in ((5, 'five'), (6, 'six'), (7, 'seven')):
    if 'd0_N%d' % N in cert:
        macros['CertDzeroN' + name] = sci_up(cert['d0_N%d' % N]['ext']['bound'])

# ---------------------------------------------------------------- rho table
rr = []
for N in range(2, 8):
    c = cert.get('d0_N%d' % N)
    if c is None or c.get('rho') == 'inf':
        rr.append((N, r'$\infty$', '---'))
    else:
        rr.append((N, '$[%.3f,\\,%.3f]$' % (c['rho_lo'], c['rho_hi']), '%.2f' % c['t_at_boundary']))
tab = r"""\begin{table}[h]
\centering
\caption{\rev{Certified admissible radius of the vertex expansions in $d=0$
($\lambda=1$, $\Lambda=4$): positivity of $\tilde\Gamma_k''+R_k$ is proved on
$|\varphi|\le\rho_-$ for every $k$, and a sign change at $|\varphi|=\rho_+$ is
exhibited at the scale $k$ shown.}}
\label{tab:rho}
\small\setlength{\tabcolsep}{4pt}
\begin{tabular}{lcccccc}
\hline\hline
$N$ & """ + ' & '.join(str(n) for n, _, _ in rr) + r""" \\
\hline
$[\rho_-,\rho_+]$ & """ + ' & '.join(v for _, v, _ in rr) + r""" \\
$k$ at the boundary & """ + ' & '.join(v for _, _, v in rr) + r""" \\
\hline\hline
\end{tabular}
\end{table}
"""
open(os.path.join(SRC, 'tab_rho.tex'), 'w').write(tab)
vals = {}
for key, d in rs.items():
    if key == 'resolution':
        continue
    for N, (r, k) in d.items():
        if r is not None and int(N) <= 7:
            vals.setdefault(int(N), []).append(r)
spread = max(max(v) - min(v) for v in vals.values())
macros['RhoScanRange'] = 'up to %.1f' % (math.ceil(spread * 10) / 10)
res = max(abs(a[0] - b[0]) for a, b in rs['resolution'].values())
macros['RhoResolution'] = r'$%s$' % ('5\\times10^{-4}' if res < 5e-4 else '%.0e' % res)

# ---------------------------------------------------------------- table 2 (d = 3)
rows = []; ratios3 = {}; mu1f = []
for N in range(2, 6):
    c = cert.get('d3_N%d' % N)
    if c is None:
        continue
    e0, _ = true_err(3, N)
    b = c['ext']['bound']; ratios3[N] = b / e0
    inj, amp, dif = decomposition(c)
    rows.append('%d & %s & %s & %s & %s & %s & %s & %.2f & %.2f \\\\' %
                (N, sci(e0), sci_up(b), ratio(b / e0), sci_up(inj), sci_up(amp), sci_up(max(dif, 0)), c['ext']['beta'], c['ext']['L']))
    c1 = cert.get('d3_N%d_mu1' % N)
    if c1:
        mu1f.append(c1['ext']['bound'] / b)
    if N in (4, 5) and c['lat']:
        macros['LatDthreeN' + {4: 'four', 5: 'five'}[N]] = sci_up(c['lat']['bound'])
    if N in (4, 5):
        macros['RhoDthreeN' + {4: 'four', 5: 'five'}[N]] = '%.2f' % c['rho_float']
tab = r"""\begin{table}[h]
\centering
\caption{\rev{Three dimensions, $|\Delta t|=1.2$: true error at $x=0$ against the
certificate for the continuation at $|x|=L$, with $\bar a_s=1/(\tilde\mu_s\mu_s)$ and
$\mu_s$ from \eqref{eq:mud3}. The certificate is split into the defect injected along
the flow, $\int_0^SC\,ds$, its amplification by the scaling term,
$\int_0^S(e^{3(S-s)}-1)C\,ds$, and the diffusive growth. Parameters are chosen as in
table~\ref{tab:d0}.}}
\label{tab:d3}
\small\setlength{\tabcolsep}{4pt}
\begin{tabular}{ccccccccc}
\hline\hline
$N$ & true error & certificate & ratio & defect & scaling & diffusion & $\beta$ & $L$ \\
\hline
""" + '\n'.join(rows) + r"""
\hline\hline
\end{tabular}
\end{table}
"""
open(os.path.join(SRC, 'tab_d3.tex'), 'w').write(tab)
macros['RatioDthreeNtwo'] = '%.1f' % (math.ceil(ratios3[2] * 10) / 10) if 2 in ratios3 else '??'
macros['RatioDthreeRange'] = '%d' % math.ceil(max(ratios3.values()))
if mu1f:
    macros['MuOneFactor'] = '%.0f to %.0f' % (min(mu1f), max(mu1f))

# ---------------------------------------------------------------- rate (d = 3, N = 2)
c = cert.get('d3_N2')
if c:
    h = np.array([[t, a] for t, a, *_ in c['history']])
    S = h[-1, 0]; ih = np.argmin(abs(h[:, 0] - S / 2))
    rate = math.log(h[-1, 1] / h[ih, 1]) / (S - h[ih, 0])
    macros['RateDthree'] = '%.2f' % rate
    macros['RateExcess'] = '%.2f' % (rate - 3)
    macros['BetaDthreeNtwo'] = '%.2f' % c['ext']['beta']
    last = c['steps'][-1]
    macros['AbarBetaEnd'] = '%.2f' % (last[3] * c['ext']['beta']**2)
    sec = [ab * c['ext']['beta']**2 for a, b, C, ab, mu in c['steps'] if a >= S / 2]
    macros['AbarBetaMean'] = '%.2f' % np.mean(sec)
    i = np.argmin(abs(h[:, 0] - 1.1))
    macros['LocalRateEnd'] = '%.2f' % (math.log(h[i + 10, 1] / h[i - 10, 1]) / (h[i + 10, 0] - h[i - 10, 0]))

# ---------------------------------------------------------------- table 3 (field-dependent part)
from reference import dmat


def true_dnorm(dim, c):
    """True weighted norm of e' at the end of the flow for the continued truncation."""
    r = ref['d%d' % dim]; x = np.array(r['x']); u = np.array(r['prof'])
    du = dmat(x, 1) @ u
    co = c['final_coeffs']; L = c['der']['L']; z = c['der']['gammaE']
    def p1(t):
        return sum(co[n] * 2 * n * t**(2 * n - 1) for n in range(1, len(co)))
    def p2(t):
        return sum(co[n] * 2 * n * (2 * n - 1) * t**(2 * n - 2) for n in range(1, len(co)))
    ax = np.abs(x)
    dut = np.where(ax <= L, p1(ax), p1(L) + p2(L) * (ax - L)) * np.sign(x)
    m = np.abs(x) <= x.max() - 1.0
    w = 1 / np.cosh(z * x[m])**2
    return math.sqrt(np.trapezoid((dut[m] - du[m])**2 * w, x[m]))


rows = []; fo = []
for dim, Ns in ((0, range(2, 8)), (3, range(2, 6))):
    for N in Ns:
        c = cert.get('d%d_N%d' % (dim, N))
        if c is None:
            continue
        e0, e1 = true_err(dim, N)
        if dim == 3:
            fo.append(e1 / e0)
        b = c['fd']['bound']; tn = true_dnorm(dim, c); bn = c['der']['sqrtE']
        rows.append('%d & %d & %s & %s & %s & %s & %s & %s & %.2f \\\\' %
                    (dim, N, sci(e1), sci_up(b), ratio(b / e1), sci(tn), sci_up(bn), ratio(bn / tn), c['der']['gammaE']))
tab = r"""\begin{table}[h]
\centering
\caption{\rev{Field-dependent part of the error at the end of the flow. Left: true
value of $|e(x)-e(0)|$ at $x=1$ against the certificate \eqref{eq:fdbound}. Right:
true value of $\|e'\|_\zeta$ against the certificate of Proposition~\ref{prop:energy}.
Both certificates are for the continuation of Proposition~\ref{prop:cont}, with the
window, $\beta$ and the weight parameter $\zeta$ chosen to minimise each of them; $\zeta$
is shown.}}
\label{tab:deriv}
\small\setlength{\tabcolsep}{4pt}
\begin{tabular}{ccccccccc}
\hline\hline
 & & \multicolumn{3}{c}{$|e(1)-e(0)|$} & \multicolumn{3}{c}{$\|e'\|_\zeta$} & \\
$d$ & $N$ & true & certificate & ratio & true & certificate & ratio & $\zeta$ \\
\hline
""" + '\n'.join(rows) + r"""
\hline\hline
\end{tabular}
\end{table}
"""
open(os.path.join(SRC, 'tab_deriv.tex'), 'w').write(tab)
if fo:
    macros['FdOverOriginMin'] = '%.1f' % (math.floor(min(fo) * 10) / 10)
    macros['FdOverOriginMax'] = '%.1f' % (math.floor(max(fo) * 10) / 10)

# ---------------------------------------------------------------- references
cv = ref['d0']['conv']
macros['RefDzeroConvStep'] = sci(cv['step'], 1); macros['RefDzeroConvGrid'] = sci(cv['grid'], 1)
macros['RefDzeroConvDomain'] = sci(max(cv['domain'], 1e-16), 1)
macros['RefDzeroMinGtwo'] = '%.6f' % ref['d0']['min_G2_along_flow']
cv = ref['d3']['conv']
macros['RefDthreeConvStep'] = sci(cv['step'], 1); macros['RefDthreeConvGrid'] = sci(cv['grid'], 1)
macros['RefDthreeConvDomain'] = sci(max(cv['domain'], 1e-16), 1)
# where the weighted defect peaks in d = 3 (selected beta, middle of the flow)
import frgcert as F
xm = []; xpeak = {}
for N in range(2, 6):
    c = cert.get('d3_N%d' % N)
    if c is None:
        continue
    ts, cs, Ds = F.trajectory(3, N, c['nsteps'])
    L = c['ext']['L']; be = c['ext']['beta']
    x = np.linspace(0, L, 4001); y = x * x
    for j in (len(ts) // 4, len(ts) // 2, 3 * len(ts) // 4):
        Q = F.Q_float(cs[j], N, 1.0); sv = F.series_inverse(Q, N)
        dl = np.abs(1 / np.polyval(Q[::-1], y) - np.polyval(sv[::-1], y))
        xm.append(x[np.argmax(dl / np.cosh(be * x))])
        xpeak.setdefault(N, []).append(xm[-1])
macros['XpeakDthreeNtwo'] = '%.1f' % np.median(xpeak[2])
macros['XpeakDthreeNfive'] = '%.1f' % np.median(xpeak[5])
# sensitivity of the certificate to beta near the optimum (floating point search grid)
sens = []
for key, c in cert.items():
    if key.endswith('_mu1'):
        continue
    bc = dict((round(b, 2), v) for b, v in c['float']['beta_curve'])
    b0 = round(c['ext']['beta'], 2); v0 = bc[b0]
    for db in (-0.5, 0.5):
        if round(b0 + db, 2) in bc:
            sens.append(bc[round(b0 + db, 2)] / v0 - 1)
macros['BetaSensitivity'] = 'at most %d per cent' % math.ceil(100 * max(sens))

with open(os.path.join(SRC, 'numbers.tex'), 'w') as fh:
    fh.write('% generated by code/make_tables.py\n')
    for k in sorted(macros):
        fh.write('\\newcommand{\\%s}{%s}\n' % (k, macros[k]))
print(json.dumps(macros, indent=1))
print('ratios d0', {k: round(v, 2) for k, v in ratios0.items()}, 'd3', {k: round(v, 2) for k, v in ratios3.items()})
