"""Sensitivity of the admissible radius rho_N (d = 0) to coupling, UV scale and resolution.

Writes results/rho_scan.json.  Floating point; the bracket for the reference parameters
(lambda = 1, Lambda = 4) is certified separately in certify.py.
"""
import json, os
import numpy as np
import frgcert as F

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'results', 'rho_scan.json')


def rho(N, lam, Lam, nsteps, nf=24001, fmax=12.0):
    F.D0_INIT[:] = [0.0, 0.5, lam / 24.0]
    old = F.LAMBDA; F.LAMBDA = Lam
    ts, cs, _ = F.trajectory(0, N, nsteps)
    F.LAMBDA = old
    f = np.linspace(0, fmax, nf); y = f * f; r = np.inf; tr = None
    for j in range(len(ts)):
        Qv = np.polyval(F.Q_float(cs[j], N, ts[j]**2)[::-1], y)
        neg = np.where(Qv <= 0)[0]
        if len(neg) and f[neg[0]] < r:
            r = f[neg[0]]; tr = ts[j]
    return (None if not np.isfinite(r) else float(r)), (None if tr is None else float(tr))


out = {}
for lam in (0.5, 1.0, 2.0):
    for Lam in (4.0, 8.0):
        out['lam=%g,Lambda=%g' % (lam, Lam)] = {N: rho(N, lam, Lam, int(500 * Lam)) for N in range(2, 10)}
        print(lam, Lam, out['lam=%g,Lambda=%g' % (lam, Lam)], flush=True)
out['resolution'] = {N: [rho(N, 1.0, 4.0, n, nf=nf) for n, nf in ((2000, 24001), (8000, 48001))] for N in range(4, 8)}
F.D0_INIT[:] = [0.0, 0.5, 1.0 / 24.0]
print(out['resolution'])
with open(OUT, 'w') as fh:
    json.dump(out, fh, indent=1)
