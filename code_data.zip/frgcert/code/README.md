# Code and data: a posteriori error certificates for truncations of the functional renormalisation group

This archive reproduces every certificate, true error, table and figure of the article.

## Requirements

Python 3.12 with numpy 2.2, scipy 1.14, matplotlib, and python-flint 0.9.0 (Arb ball
arithmetic). LaTeX (pdflatex) for the article.

## Layout

- `code/`: the scripts listed below; run them from this directory.
- `results/`: the JSON output used in the article.
- `src/`: the tables, numbers and Figure 1 generated from `results/`.

## Files

- `frgcert.py`: the flows, the Runge-Kutta coefficient trajectories, the cubic Hermite
  approximation and the ball-arithmetic enclosures of its defect, residual and tail.
- `certify.py DIM N [--mu1]`: certificates for one vertex expansion (DIM = 0 or 3):
  Theorem 1 for the continued truncation (Proposition 3), the window estimate
  (Proposition 2), the field-derivative energy bound (Proposition 4) and the certified
  admissible radius. Writes `results/cert/dDIM_NN.json`. The option `--mu1` uses the
  convexity bound 1 + u'' >= 1 in d = 3.
- `reference.py`: method-of-lines reference solutions with step, grid and domain
  convergence tests, and the true errors. Writes `results/reference.json`.
- `rho_scan.py`: dependence of the admissible radius on coupling, initial scale and
  resolution. Writes `results/rho_scan.json`.
- `make_tables.py`, `make_figure.py`: tables, numbers and Figure 1 from the JSON files.
- `run_all.sh`: runs all certificates and the references.
- `check_residual.py`: largest interpolation-residual bounds per configuration.

## Reproduction

    cd code
    ./run_all.sh
    python3 rho_scan.py
    python3 make_tables.py
    python3 make_figure.py

All certificates are upper bounds evaluated in ball arithmetic at 106-bit precision.
Floating-point arithmetic is used only to select the parameters beta, gamma, zeta and L
and in the reference solutions.
