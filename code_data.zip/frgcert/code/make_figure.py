"""Figure 1: certificate and true error along the flow (src/fig_flow.pdf)."""
import json, os, glob
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
R = os.path.join(ROOT, 'results')
ref = json.load(open(os.path.join(R, 'reference.json')))
COL = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100']
plt.rcParams.update({'font.size': 9, 'axes.linewidth': 0.6, 'xtick.major.width': 0.6,
                     'ytick.major.width': 0.6, 'font.family': 'serif', 'mathtext.fontset': 'cm',
                     'pdf.fonttype': 42})
fig, axs = plt.subplots(1, 2, figsize=(6.3, 2.9), constrained_layout=True)
FLOOR = 1e-12      # below the accuracy of the reference solutions
for ax, dim, Ns, lab in ((axs[0], 0, (2, 3, 4, 5), '(a) $d=0$'), (axs[1], 3, (2, 3, 4, 5), '(b) $d=3$')):
    rec = np.array(ref['d%d' % dim]['rec'])
    for i, N in enumerate(Ns):
        c = json.load(open(os.path.join(R, 'cert', 'd%d_N%d.json' % (dim, N))))
        h = np.array([[t, a] for t, a, *_ in c['history']])
        tr = np.array(ref['trunc']['d%d_N%d' % (dim, N)])
        s_tr = (4.0 - tr[:, 0]) if dim == 0 else tr[:, 0]
        s_ref = (4.0 - rec[:, 0]) if dim == 0 else rec[:, 0]
        err = np.abs(np.interp(s_ref, s_tr, tr[:, 1]) - rec[:, 1])
        s_h = (4.0 - h[:, 0]) if dim == 0 else h[:, 0]
        ax.semilogy(s_h, h[:, 1], color=COL[i], lw=1.6)
        m = err > FLOOR
        ax.semilogy(s_ref[m], err[m], color=COL[i], lw=1.2, ls=(0, (3, 2)))
    ax.set_xlabel('$s=\\Lambda-k$' if dim == 0 else '$s=-t$')
    ax.set_title(lab, fontsize=9, loc='left')
    ax.grid(True, which='major', lw=0.3, color='#d9d8d4')
    ax.set_xlim(0, 4.0 if dim == 0 else 1.2)
    ax.set_ylim(FLOOR, None)
    for sp in ('top', 'right'):
        ax.spines[sp].set_visible(False)
axs[0].set_ylabel('error at the origin')
from matplotlib.lines import Line2D
hs = [Line2D([], [], color=COL[i], lw=1.6) for i in range(4)] + \
     [Line2D([], [], color='#52514e', lw=1.6), Line2D([], [], color='#52514e', lw=1.2, ls=(0, (3, 2)))]
fig.legend(handles=hs, labels=['$N=2$', '$N=3$', '$N=4$', '$N=5$', 'certificate', 'true error'],
           loc='outside upper center', ncol=6, frameon=False, fontsize=8, handlelength=1.8, columnspacing=1.2)
fig.savefig(os.path.join(ROOT, 'src', 'fig_flow.pdf'))
fig.savefig(os.path.join(R, 'fig_flow.png'), dpi=200)
print('figure written')
